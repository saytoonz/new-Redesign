package com.nsromapa.say.emogifstickerkeyboard.internal.sound;

import androidx.annotation.NonNull;

import java.io.File;

public interface SoundSelectListener {
    void onSoundSelectListner(@NonNull File souncImage);
}
