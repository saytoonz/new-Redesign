package com.nsromapa.say.emogifstickerkeyboard.internal.sticker;

import androidx.annotation.NonNull;

import java.io.File;

public interface StickerSelectListener {
    void onStickerSelectListner(@NonNull File sticker);
}
