package com.nsromapa.say.emogifstickerkeyboard.internal.sticker;

public interface StickerProvider {
    int getLink(int url);
}
