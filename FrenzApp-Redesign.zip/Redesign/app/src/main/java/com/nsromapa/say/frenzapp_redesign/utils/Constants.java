package com.nsromapa.say.frenzapp_redesign.utils;

public class Constants {
    public static final String NEWS_FEEDS = "http://192.168.43.22/frenzapp/posts";
    public static final String DISCOVER_STORIES = "http://192.168.43.22/frenzapp/discover_stories";
    public static final String ALL_FOLLOWERS = "http://192.168.43.22/frenzapp/all_followers";
    public static final String CHATS = "http://192.168.43.22/frenzapp/chats";

}
