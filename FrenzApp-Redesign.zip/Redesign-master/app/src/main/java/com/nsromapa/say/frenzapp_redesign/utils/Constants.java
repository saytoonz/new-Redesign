package com.nsromapa.say.frenzapp_redesign.utils;

public class Constants {
    public static final String NEWS_FEEDS = "http://192.168.8.100/frenzapp/posts";
    public static final String DISCOVER_STORIES = "http://192.168.8.100/frenzapp/discover_stories";
}
